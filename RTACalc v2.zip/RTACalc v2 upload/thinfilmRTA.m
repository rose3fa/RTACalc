function [wl, n_substrate, R, T, A, nData, nDataInterp, kData, kDataInterp, N] = thinfilmRTA(lam0, lam1, dlam, layers, thicknesses, angle, polarization)


%% This script outputs spectral R, T, A for thin film stacks

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%   About this script   %%%%%%%%%%%%%%%%%%%%%%%%%%%
%% How to use this function, and functions in general (basic usage)
    %      This file is a function, so you call it from either the command
    % window or another script with thinfilmRTA(...) and filling in each of
    % the variables according to the description below.
    %      To access the output variables either in the workspace or in
    % another script, you would use: [wl, n_substrate, R, T, A, nData,
    % nDataInterp, kData, kDataInterp, N] = thinfilmRTA(...), where each of
    % the variables in [] can be called anything (i.e., you don't have to
    % use the names above) and if a variable is unneeded it can be replaced
    % with ~ to save computation time. Further, to suppress output of each
    % variable in the Command Window, just add ; at the end of the command.

%% Input variables
    % lam0  Smallest wavelength of interest (nm)
    % lam1  Largest wavelength of interest (nm)
    % dlam  Wavelength interval/resolution (nm)
    % layers is a cell array entered e.g. {'fused silica' 'Ag' 'air'}
        % The first and last layers will be modeled as lossless
            % semi-infinite slabs; they can have dispersion but only the
            % real part of the refractive index will be taken.
        % Light is incident from first layer
        % Dielectric function are pulled from the 'Refractive Indices'
            % folder in the same directory as this function.
        % Naming of refractive index files is, e.g. 'Ag_nm_n' where all
            % files use 'nm,' 'n' can be 'n' or 'k,' and the material name
            % changes.
        % Call the layer based on the name of the file before the first
            % underscore, e.g. 'Ag'
    % thicknesses is a vector (nm) that doesn't include the first or last
        % layers since they are always semi-infinite slabs
    % angle of incidence (deg), row vector to calculate multiple angles -
        % updated 2020
    % polarization, 0 for TE (s-polarized), otherwise (any value other than
        % 0) TM (p-polarized)
    
%% Output variables
    % wl, a 1xn vector containing the wavelengths studied (nm)
    % n_substrate, a nx1 vector containing the real part of the index of
        % refraction of the substrate for each corresponding wavelength.
        % The underlying program neglects the imaginary part of the
        % substrate. Having n_substrate is using for calculating dispersion
        % plots
    % R, T, and A are the reflectance, trasmittance, and absorptivity (or
        % absorptance, but not absorbance...) at each wavelength along the
        % rows and each angle along columns, as a decimal value - updated
        % 2020
    % nData and kData are cells (which are just arrays that can contain any
        % kind of information (not just numbers) with varying sizes) that
        % contain the actual imported real and imaginary refractive index
        % and wavelength data
    % nDataInterp and kDataInterp are the interpolated/extrapolated
        % refractive index data. Wavelengths are not included as they
        % correspond to the wl variable. Included so one can check that the
        % refractive index data being used makes sense, especially if it's
        % being extrapolated.
    % N is the number of layers in the stack
   
%% jreftran_rt.m
    % This script (thinfilmRTA.m) calls upon the jreftan_rt.m script
    % written by someone else
    %   function [r,t,R,T,A]=jreftran_rt(l,d,n,t0,polarization)
    %   l = free space wavelength, nm
    %   d = layer thickness vector, nm
    %       same length as n vector
    %       Ex: [NaN,200,NaN], 1st and last layers are semi-infinite slabs
    %   n = layer complex refractive index vector n = n + ik
    %       same length as d vector
    %       Ex: [1,0.9707 + 1.8562i,1], 1st and last layers are lossless
    %   t0 = angle of incidence, radians
    %   polarization should be 0 for TE (s-polarized), otherwise (any value
    	%   other than 0) TM (p-polarized)       
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        

%% Start importing and interpolating the refractive indices at the
%  appropriate wavlengths

wl = lam0:dlam:lam1; % Creates a vector from the desired wavelength range.
                     % If lam0 + n*dlam doesn't equal lam1 for any n, it 
                     % will round down to the nearest value to lam1

[n_substrate, n, nData, nDataInterp, kData, kDataInterp, N] = n_interpolate(wl, layers);


%% Construct a vector of the thicknesses for each layer
d = zeros(1,length(thicknesses)+2); % preallocate memory
d(1) = NaN; % First and last media are semi-infinite
d(end) = NaN;

% Other films take thickness specified when calling function
for p = 2:length(d)-1
    d(p) = thicknesses(p-1);
end
 
%% Call the transfer matrix R, T, A calculator function and build spectra
t0 = pi*angle/180; % Convert angle to radians
l = length(wl);
m = length(angle);
wl = wl';

% Preallocate memory
R = zeros(l,m);
T = zeros(l,m);
A = zeros(l,m);

% Calculate for each angle
for q = 1:m
       [~,~,R(:,q),T(:,q),A(:,q)]=jreftran_rt_ahr(wl,d,n,t0(q),polarization);
end




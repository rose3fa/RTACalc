function [] = export_dispersion_data(x, eV, data, dispersionX, directory, saveTitle, f)
%% Exports the dispersion data

%% Inputs
% x is the x-axis data. Matrix w/ same demensions as data. 
% eV is the incident photon energy in eV. Matrix w/ same demensions as data. 
% data is R, T, or A
% dispersionX defines type of x-axis data, x
  %       0: internal angle [degrees]
  %       1: external angle [degrees] of right angle prism
  %       2: kx [nm-1], in-plane wavevector, kx = 2pi/lambda n sin(theta), 
  %          where lambda is vacuum wavelength, n is (wavelength-dependent)
  %          refractive index of layer 1 in thinfilmRTA (or prism material
  %          for such data), and theta is the internal angle-of-incidence
% directory is where data will be saved
% saveTitle is used for the file names
% f is used to generate a suffix for the file names
  

%% Output new E vs kx/angle datafiles?            
    % Save the photon energy data
    dlmwrite(fullfile(directory, [saveTitle '_' num2str(f) 'eV.txt']), eV,'delimiter','\t'); % Use the original eV data

    % Save the kx or angle or external angle data
    if dispersionX == 0      % then x-axis is internal angle (deg)
        % Save the angle data
        dlmwrite(fullfile(directory, [saveTitle '_' num2str(f) 'angle.txt']), x,'delimiter','\t');
        % Save the R, T, or A data
        dlmwrite(fullfile(directory, [saveTitle '_' num2str(f) 'data_eV_angle.txt']), data,'delimiter','\t');

    elseif dispersionX == 1  % x-axis is external angle of right angle prism
        dlmwrite(fullfile(directory, [saveTitle '_' num2str(f) 'externalAngle.txt']), x,'delimiter','\t');
        dlmwrite(fullfile(directory, [saveTitle '_' num2str(f) 'data_eV_externalAngle.txt']), data,'delimiter','\t');

    else                    % x-axis is wavenumber (nm-1)
        dlmwrite(fullfile(directory, [saveTitle '_' num2str(f) 'kx.txt']), x,'delimiter','\t');
        dlmwrite(fullfile(directory, [saveTitle '_' num2str(f) 'data_eV_kx.txt']), data,'delimiter','\t');
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Test RTACalc v2
% This script calculates the dispersion of Kretschmann-Raether
% plasmon--exciton strong coupling between plasmons in a thin Ag film and excitons
% in a two-dimensional hybrid organic−inorganic perovskite (HOIP) 
% semiconductor. In the figure that gets generated, you'll see two lines
% that exhibit anti-crossing behavior at the photon energy of the HOIP
% exciton near 2.5 eV. This is a classic signature of strong coupling. You
% can play with this by varying the thickness of the HOIP. When it is thin (~1 nm),
% you'll be seeing the usual plasmon dispersion. As you make it thicker you
% turn on strong coupling, while simultaneously red-shifting the plasmon.
% If you make the HOIP layer too thick, you'll red-shift the plasmon to
% below the exciton and you'll lose the strong coupling. 
%
% We run this script from a convenient folder and Matlab adds this folder
% (aka directory) to the path (meaning, if we call functions it will look
% for them in any directory on its path. However, this script calls
% functions in the 'RTACalc v2' directory, which may be located elsewhere
% (e.g. in the MATLAB directory). Therefore, we must add RTACalc v2 to the
% path. 

% NOTE: This is one piece of the script that may need to be updated by
% users other than myself, since this location may vary. Also, I'm using
% the Mac directory format, which is not universal. But, update this to
% point to your RTACalc v2 folder and then you can run this script from any
% directory
%    addpath(genpath('/Users/arose2/Documents/MATLAB/Transfer Matrix Reflection Calculator/RTACalc v2/'))

%% Setup output directory -- You update these
date = '2021-10-19'; % Used for saving files
suffix = 'strongCouplingExample'; % Used to create subfolders 
                                             % for runs on same day
experimentFolder = fullfile('Output', date, suffix);
directory = fullfile(pwd, experimentFolder);

warning('off', 'MATLAB:MKDIR:DirectoryExists');
mkdir(directory); % Make the directory to save output, and don't 
                     % tell me that the directory already exists 
                     % when it does
                            
%% Input parameters -- You update these
hc = 1239.84198405504; % Planck's constant x speed of light; used to convert between photon energy (eV) and wavelength (nm)
lam0 = 375;        % Smallest wavelength of interest (nm), use hc/eV if you know photon energy in (eV)
lam1 = 750;        % Largest wavelength of interest (nm)
dlam = 0.1;         % Wavelength interval/resolution (nm)
% Layers: NBK7 is a common glass. This is the semi-infinite input layer. Ti
% is often used as an adhesion layer for Au or Ag to stick to glass. This
% model is for a plasmonic thin film (Ag) so using the least amount of Ti
% is important to not damp the plasmon. Ag2S is commonly formed on Ag
% surfaces. 2DHOIP is a perovskite material with a strong excitonic feature
% that will be good for observing strong coupling. Air is the semi-infinite
% material on the top of the stack
layers = {'NBK7' 'ti-palik' 'Ag' 'Ag2S' '2DHOIP' 'air'}; % See thinfilmRTA.m for explanation
thicknesses = [1 50 0.25 15];                                  % ditto
angle = [40:0.1:89.9]; % [min angle (deg),increment/resolution (deg), max angle (deg)] Note that this is the angle of incidence (a.o.i.) in layer 1; see inputType note below for more details
polarization = 1;  % 0 for TE (s-polarized), otherwise (any value other than 0) TM (p-polarized)
inputType = 0;      %  inputType - generally, use 0
                    %       0: internal angle [degrees] in right angle prism or equivalent to 
                    %          the angle-of-inicidence in layer 1 when calling thinfilmRTA
                    %       1: external angle [degrees] of right angle prism (i.e. in air, 
                    %          illuminated through one of the 90° square faces onto the 
                    %          hypotenuse. This is the angle-of-incidence with repect to the 
                    %          normal of the hypotenuse. Useful when dealing with real data
                    %          collected in this prism configuration
dispersionType = 2; % Calculate: 0 reflectance (R), 1 trasmittance (T), or 
                               % 2 absorptivity (A) dispersion
figOnOff = 1;      % 1 to diplay figures, 0 to hide them
figSave = 1;       % 1 to save figures, 0 to not; saves as matlab .fig and .png., adds significant computation time
dataSave = 1;      % 1 to save data, 0 to not
dispersionX = 2;   % x-axis representation: 
                      %       0: internal angle [degrees] (see above)
                      %       1: external angle [degrees] of right angle prism (see above)
                      %       2: kx [nm-1], in-plane wavevector, kx = 2pi/lambda n sin(theta), 
                      %          where lambda is vacuum wavelength, n is (wavelength-dependent)
                      %          refractive index of layer 1 in thinfilmRTA (or prism material
                      %          for such data), and theta is the internal angle-of-incidence

range = [-inf inf hc/lam1 hc/lam0]; % [(min k/angle) (max k/angle) (min energy) (max energy)]
                                     % This is not the calculated range,
                                     % but the plotted range. The first two
                                     % values depend on the choice of
                                     % dispersionX above. Units: k (nm-1),
                                     % angle (deg), energy (eV)
                                     % Set to -inf or inf to autoscale

%% Calculate! -- You shouldn't have to touch these

% 1. Calculate R, T, and/or A
    % [wl, n_substrate, R, T, A, nData, nDataInterp, kData, kDataInterp, N]
    % thinfilmRTA possible outputs
    if dispersionType == 0 % Reflectance
    [wl, n_substrate, R, ~, ~, ~, ~, ~, ~, ~] = thinfilmRTA(lam0, lam1, dlam, layers, thicknesses, angle, polarization);
    data = R;
    elseif dispersionType == 1 % Transmittance
    [wl, n_substrate, ~, T, ~, ~, ~, ~, ~, ~] = thinfilmRTA(lam0, lam1, dlam, layers, thicknesses, angle, polarization);
    data = T;
    else % Absorptivity
    [wl, n_substrate, ~, ~, A, ~, ~, ~, ~, ~] = thinfilmRTA(lam0, lam1, dlam, layers, thicknesses, angle, polarization);
    data = A;
    end
    
%% Set up matrices for data output and/or plotting dispersion  
%  To make things easier for plotting, the x and y axis data is made into a
%  matrix the same size as the R/T/A matrix. For kx or theta_external

% 2. Calculate the photon energy from wavelength  
    % Compute E vector based on wavelength range of interest

    eV = hc ./ wl;   % Convert wavelengths to energy (eV)
    % Turn eV and angle vectors into matrices the same size as A matrix
    NeV = length(eV);
    eV = ones(NeV,length(angle)).*eV;

% 3. Calculate theta/external theta/kx matrix
% The angle vector used above is the angle of incidence, in degrees, in
% layer 1. For dispersion plots, we want to convert this to in-plane
% wavevector. For 90° prism modeling, we want to know the external angle of
% incidence in air (see note above for the dispersionX variable). 
    [x] = internalAngle_externalAngle_kx_converter(angle,eV,n_substrate,inputType,dispersionX);
    
% 4. Generate plot titles and file names
    [plotTitle, saveTitle] = generate_dispersion_title(dispersionType, layers, thicknesses, polarization);
    
% 5. Create the plots and save/display them
    [f] = plotDispersion(x, eV, data, dispersionX, dispersionType, range, directory, figOnOff, figSave, plotTitle, saveTitle);

% 6. Save the data, if desired
    if dataSave == 1 
        export_dispersion_data(x, eV, data, dispersionX, directory, saveTitle, f);
    else
    end
  


clearvars date suffix lam0 lam1 dlam layers angle polarization R directory experimentFolder n_substrate note thicknesses wl A dataSave dispersionX figOnOff figSave range;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
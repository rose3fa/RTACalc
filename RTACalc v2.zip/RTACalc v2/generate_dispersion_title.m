function [plotTitle, saveTitle] = generate_dispersion_title(dispersionType, layers, thicknesses, polarization)
%% Generates plot titles and file names for dispersion plots

%  R, T, or A data?
    if dispersionType == 0
        dataType = 'Reflectance';
    elseif dispersionType == 1
        dataType = 'Transmittance';
    else
        dataType = 'Absorptivity';
    end
        

% Create title text

    % Layers, initial
    stack = [layers{1}, ' / '];
    % Layers, middle
    for q=2:length(layers)-1
        stack = [stack,layers{q},' / '];
    end
    % Layers, end
    stack = [stack, layers{end}];

    % Layer thicknesses, initial
    note = [' ' layers{2} ': ' num2str(thicknesses(1))  ];
    % Layer thicknesses, complete
    if length(layers) > 3
        for q = 3:length(layers)-1
            note = [note,', ' layers{q} ': ' num2str(thicknesses(q-1)) ];
        end
    end


    % Polarization        
    if polarization==0
    pol =  'TE';
    else
    pol = 'TM';
    end

    % Put it all together
    plotTitle = {[dataType ' Dispersion with ' pol '-polarization'], ['Layers: ' stack], ['Thicknesses: ' note, ' (nm)']};

% Create name to save image
    saveStack = strcat(layers{1},'-');
    for q=2:length(layers)-1
        saveStack = strcat(saveStack,layers{q},'-');
    end
    saveStack = strcat(saveStack, layers{end});
    saveTitle = [dataType ' Dispersion with ' pol '-polarization ', saveStack, ', ' note];
    saveTitle = replace(saveTitle, ':', '');  % colons aren't allowed in Windows filenames, so remove them  
    
    
    
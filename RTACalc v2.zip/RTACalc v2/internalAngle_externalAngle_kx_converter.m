function [x] = internalAngle_externalAngle_kx_converter(angle,eV,n_substrate,inputType,outputType)

%% This function is given and series of angles as a row vector and converts them to internal or external angle for a right angle prism or in-plane wavevector

%% Inputs
%  angle - row vector of angles
%  eV - incident photon energy, column vector
%  n_substrate - refractive index of substrate, i.e. layer 1 of thinfilmRTA
%       or material of prism for such data. Column vector with rows
%       corresponding to the wavelength or photon energy used. Real part.
%  inputType - generally, use 0
%       0: internal angle [degrees] in right angle prism or equivalent to 
%          the angle-of-inicidence in layer 1 when calling thinfilmRTA
%       1: external angle [degrees] of right angle prism (i.e. in air, 
%          illuminated through one of the 90° square faces onto the 
%          hypotenuse. This is the angle-of-incidence with repect to the 
%          normal of the hypotenuse. Useful when dealing with real data
%          collected in this prism configuration
%  outputType - 
%       0: internal angle [degrees] (see above)
%       1: external angle [degrees] of right angle prism (see above)
%       2: kx [nm-1], in-plane wavevector, kx = 2pi/lambda n sin(theta), 
%          where lambda is vacuum wavelength, n is (wavelength-dependent)
%          refractive index of layer 1 in thinfilmRTA (or prism material
%          for such data), and theta is the internal angle-of-incidence

%% Outputs
%  x -  [deg or nm-1] matrix with width equal to number of input angles and
%       length equal to NeV. Values are dependent on specified outputType. 
%       The values in each column may or may not be equal. E.g., when 
%       converting from internal to external angle, there is generally a
%       wavelength-dependence from the refractive index, so each row will 
%       vary. When converting to kx, there is a direct wavelength
%       dependence, as well as indirect thru the refractive index
             
%% Get the full matrix for the input angle
   Nangles = length(angle);
   NeV = length(eV);
   angle = ones(NeV,Nangles).*angle;
    
%% If input type is internal angle, follow this path
if inputType == 0
    
    % If output type is internal angle, do this
    if outputType == 0
        x = angle;
        
    % If output type is external angle, do this
    elseif outputType == 1
        % Create a substrate index matrix
          n = ones(NeV,Nangles).*n_substrate;
        % Calculate external angles. Angles outside of 0-90° may be
        % generated as well as complex values, despite being unobservable.
        % We'll take the real part, but allow the unphysical values. 
          x = real(45 + asind(n.*sind(angle-45)));
          
    % If output type is kx, do this
    else
        % Create a substrate index matrix
          n = ones(NeV,Nangles).*n_substrate;
        % Calculate in-plane wavevector
          hc = 1239.84198405504;
          x = 2*pi.*n.*eV/hc.*sin(pi*angle/180);
    end

%% If input type is external angle, follow this path
else
    % If output type is internal angle, do this
    if outputType == 0
        % Create a substrate index matrix
          n = ones(NeV,Nangles).*n_substrate;
        % Calculate internal angle. There should be only real values
        % between 0 and 90.
          x = 45 + asind(sind(angle-45)./n);
        
    % If output type is external angle, do this
    elseif outputType == 1
          x = angle;
          
    % If output type is kx, do this
    else
        % Create a substrate index matrix
          n = ones(NeV,Nangles).*n_substrate;
        % Calculate internal angle. There should be only real values
        % between 0 and 90.
          angleIn = 45 + asind(sind(angle-45)./n);
        % Then, convert internal angle to kx
          hc = 1239.84198405504;
          x = 2*pi.*n.*eV/hc.*sin(pi*angleIn/180);
    end
end
                        
                  
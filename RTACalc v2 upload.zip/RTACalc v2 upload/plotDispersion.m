function [f] = plotDispersion(x, eV, data, dispersionX, dispersionType, range, directory, figOnOff, figSave, plotTitle, saveTitle)
%% This function plots dispersion of a thin film stack and displays and/or saves the figure
   
%% Inputs
% x is the x-axis data. Matrix w/ same demensions as data. 
% eV is the incident photon energy in eV. Matrix w/ same demensions as data. 
% data is R, T, or A
% dispersionX defines type of x-axis data, x
  %       0: internal angle [degrees]
  %       1: external angle [degrees] of right angle prism
  %       2: kx [nm-1], in-plane wavevector, kx = 2pi/lambda n sin(theta), 
  %          where lambda is vacuum wavelength, n is (wavelength-dependent)
  %          refractive index of layer 1 in thinfilmRTA (or prism material
  %          for such data), and theta is the internal angle-of-incidence
% dispersionType define if data is R, T, or A
  % 0 reflectance (R), 1 trasmittance (T), or 2 absorptivity (A) dispersion

            
            
%% Set up matrices for plotting
    % pcolor is used to make the surface plot, however, it throws away data
    % rather than just plotting a color pixel for every data point
    % The code below creates matrices out of the x and y axes that
    % correspond to the edges of where each pixel should be rather than the
    % center coordinates of each pixel. Then, the data matrix has a
    % blank row and column added so that when pcolor deletes the last row
    % and column it won't lose any information.

    % Create the matrices for the pixel edges for x and y axis
        y = eV;

        % Find differences between adjacent points
        xSplit = diff(x,1,2)/2;              
        ySplit = diff(y,1,1)/2;
    
        % Create data points for the edge of each pixel by adding or
        % subtracting the difference between adjacent points
        xEdges = [x(:,1)-xSplit(:,1) x(:,2:end)-xSplit x(:,end)+xSplit(:,end)];
        yEdges = [y(1,:)-ySplit(1,:); y(2:end,:)-ySplit; y(end,:)+ySplit(end,:)];
        
        % Add an extra row or column so the x and y matrices will have the
        % same size
        xEdges = [xEdges; xEdges(1,:)];
        yEdges = [yEdges yEdges(:,1)];
    
        % Make the data matrix the same size as the pixel edge matrices. 
        % The last row and column are ignored. The default shading of
        % the pcolor function will color each pixel according to the value at
        % the corner of that pixel with the smallest indices
        data = [[data zeros(size(data,1),1)] ; zeros(1,size(data,2)+1)];

 %% Set up axes labelling
    % Plot vs kx or angle
    if dispersionX == 0     % then x-axis is angle (deg)
       xLabel = '\textbf{Angle} $\theta \ \  (degrees)$'; 
    elseif dispersionX == 1 % then x-axis is external angle of right angle prism (deg)
       xLabel = '\textbf{External Angle} $\theta \ \  (degrees)$'; 
    else                    % x-axis is wavenumber (nm-1)
       xLabel = '\textbf{Wavenumber} $\frac{2\pi}{\lambda}n\sin{\theta} \ \  (nm^{-1})$';
    end
    
    % y-axis
    yLabel = '\textbf{Photon Energy} $(eV)$';

    % Color label
    if dispersionType == 0
        dataType = 'Reflectance';
    elseif dispersionType == 1
        dataType = 'Transmittance';
    else
        dataType = 'Absorptivity';
    end
        
    %% Set up plot
    if figOnOff == 0 && figSave == 0  % Do not make the figure
        figure; % I apologize, this must not be very efficient and is certainly not elegant, but I need this for counting
        g = get(groot,'CurrentFigure'); % f.Number will give current fig number
        f = g.Number;
    else                              % Make the figure
        font = 24;

        Plot = figure;
        % Show or hide the figure
        if figOnOff == 0
            Plot.Visible = 'off';
        else
        end
        
        set(Plot, 'Units', 'normalized');
        set(Plot, 'Position', [0 0 1 1]);
        axes('FontSize', font)  ;
        xlabel(xLabel, 'FontSize', font, 'Interpreter','latex');
        ylabel(yLabel, 'FontSize', font, 'Interpreter','latex');

        hold on
            plot = pcolor(xEdges,yEdges,data);
            plot.EdgeColor = 'none';
            colormap('hot')
            axis(range)
            c=colorbar;
            caxis([0  inf])
            c.Label.String = dataType;
            title(plotTitle, 'FontSize', font+1)
            ax = gca;
            ax.TickDir = 'out';
            ax.Layer = 'top';
            ax.Box = 'on';
            ax.XMinorTick = 'on';
            ax.YMinorTick = 'on';    
        hold off

        g = get(groot,'CurrentFigure'); % g.Number will give current fig number
        f = g.Number;
        
        %% Save figures ?
        if figSave == 0
        else
            saveas(Plot, fullfile(directory,[saveTitle '_' num2str(f) '.png']));
            savefig(Plot, fullfile(directory,[saveTitle '_' num2str(f) '.fig']));
        end
    end
        
        % To close the figure after each run (even for figures that are set
        % to not display, the figure is still held in memory), uncomment
        % below. Otherwise, leaving it commented out helps number files of separate runs
        % sequentially
%             if figOnOff == 0
%               close(Plot);% invisible figures are still saved in memory and can be 
%               % called from the command line, so let's clear it out -- not
%               % sure how to do this
%             else
%             end
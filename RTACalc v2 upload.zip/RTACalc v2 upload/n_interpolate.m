function [n_substrate, n, nData, nDataInterp, kData, kDataInterp, N] = n_interpolate(wl, layers)


%% This script outputs interpolated/extrapolated refractive indices

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%   About this script   %%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Input variables
    % wl [nm] row vector of wavelengths of interest
    % layers is a cell array entered e.g. {'fused silica' 'Ag' 'air'}
        % The first and last layers will be modeled as lossless
            % semi-infinite slabs; they can have dispersion but only the
            % real part of the refractive index will be taken.
        % Light is incident from first layer
        % Dielectric function are pulled from the 'Refractive Indices'
            % folder in the same directory as this function.
        % Naming of refractive index files is, e.g. 'Ag_nm_n' where all
            % files use 'nm,' 'n' can be 'n' or 'k,' and the material name
            % changes.
        % Call the layer based on the name of the file before the first
            % underscore, e.g. 'Ag'
            
%% Output variables
    % n_substrate, a nx1 vector containing the real part of the index of
        % refraction of the substrate (i.e. layer 1) for each corresponding wavelength.
        % The underlying program neglects the imaginary part of the
        % substrate. 
    % n is the interpolated/extrapolated complex refractive index. n =
        % n'+ik. k is removed for 1st and last layers. 
    % nData and kData are cells (which are just arrays that can contain any
        % kind of information (not just numbers) with varying sizes) that
        % contain the actual imported real and imaginary refractive index
        % and wavelength data
    % nDataInterp and kDataInterp are the interpolated/extrapolated
        % refractive index data. Wavelengths are not included as they
        % correspond to the wl variable. Included so one can check that the
        % refractive index data being used makes sense, especially if it's
        % being extrapolated.
    % N is the number of layers in the stack

%% Start importing and interpolating the refractive indices at the
%  appropriate wavlengths

        % wl = lam0:dlam:lam1; % Creates a vector from the desired wavelength range.
        %                      % If lam0 + n*dlam doesn't equal lam1 for any n, it 
        %                      % will round down to the nearest value to lam1

% Infer file names from function input and import the Refractive Index data
delimiter = '\t';   % Dispersion files are tab delimited
N = length(layers); % Number of layers

% Preallocate memory for faster computation
    % Cells are used for generic arrays or vectors of strings (or any type
    % of data) while actual vectors or arrays can only contain numbers and
    % have to have a regular shape (e.g. cell {1 2 3; 4 5} is OK, but array
    % [1 2 3; 4 5] is not OK
    nFileName = cell(1,N);      % n for real part of refractive index
    kFileName = cell(1,N);      % k for imaginary part of refractive index
    nFullFileName = cell(1,N);
    kFullFileName = cell(1,N);
    nData = cell(1,N);
    kData = cell(1,N);
%     nDataInterp = cell(1,N);
%     kDataInterp = cell(1,N);
    nDataInterp = zeros(length(wl),N);
    kDataInterp = zeros(length(wl),N);


for k = 1:N
  nFileName{k} = strcat(layers{k},'_nm_n.txt');  % Create the n file names
  kFileName{k} = strcat(layers{k},'_nm_k.txt');  % Create the k file names
  % Create the n file names including the full path
  % Note that using fullfile to create directory paths should be OS
  % agnostic. E.g., '~/Refractive Indices/Ag_nm_n' would work on a Mac, but
  % not on a PC    
  nFullFileName{k} = fullfile('Refractive Indices', nFileName{k});
  % Create the k file names including the full path
  kFullFileName{k} = fullfile('Refractive Indices', kFileName{k});
  
  
  % Import the data
      % Call wavelength (nm) as, eg,    nData{1}(:,1), and 
      % call index as, eg,              nData{1}(:,2)
      % where {1} says to use the first layer's data, : says to take all
      % rows, and 1 says to take the first column, so you'll end up with
      % nx1 vectors for this example
  nData{k} = importdata(nFullFileName{k}, delimiter);
  kData{k} = importdata(kFullFileName{k}, delimiter); 
  
  % Interpolate and extrapolate the data at the requested wavelengths
    % pchip will also be used to extrapolate. If extrapolation method isn't
    % good, add data points to dispersion text files to correct (if valid
    % to do so)
%   nDataInterp{k} = interp1(nData{k}(:,1),nData{k}(:,2),wl','pchip');
%   kDataInterp{k} = interp1(kData{k}(:,1),kData{k}(:,2),wl','pchip');
%   nDataInterp2(:,k) = nDataInterp{k};
  nDataInterp(:,k) = interp1(nData{k}(:,1),nData{k}(:,2),wl','pchip');
  kDataInterp(:,k) = interp1(kData{k}(:,1),kData{k}(:,2),wl','pchip');
end

%% Construct a vector of n and k data 
%  Ignore wavelength data as the interpolated values all share the same
%  wavelength vector, wl
n = zeros(length(wl),N); % preallocate memory
n(:,1) = nDataInterp(:,1); % First medium is lossless, so only taken n data
n(:,end) = nDataInterp(:,end); % Final medium is lossless, so only taken n data
n_substrate = n(:,1); % Output substrate index to help with dispersion plots

% For other films, n = n + ik
for k = 2:N-1
n(:,k) = nDataInterp(:,k)+1i*kDataInterp(:,k);
end
